import Layout from '../../common/layout/Layout';
import './Members.scss';

export default function Members() {
	return (
		<Layout title={'Members'}>
			<p>회원가입 페이지입니다.</p>
		</Layout>
	);
}
